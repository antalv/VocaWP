// Speech synthesis
//     const synth = window.speechSynthesis;
//     const inputTxt = document.querySelector('.text');
//     const play = document.querySelector('.play');




    // function speak() {
    //     if (synth.speaking) {
    //         synth.cancel();
    //         setTimeout(speak, 300);
    //     } else {
    //         const utterThis = new SpeechSynthesisUtterance(inputTxt.value);
    //         voices = synth.getVoices();
    //         let selectedOption = 'Google Deutsch';
    //         for (i = 0; i < voices.length; i++) {
    //             if (voices[i].name === selectedOption) {
    //                 utterThis.voice = voices[i];
    //             }
    //         }
    //
    //         synth.speak(utterThis);
    //     }
    // // }
    // play.onclick = function (event) {
    //     event.preventDefault();
    //     speak();
    // };
    //

